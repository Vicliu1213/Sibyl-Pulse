

def dialog_map(module: str, content: dict = None) -> None:

    if module == "stock_analysis":
        stock_symbol = content["stock_symbol"]
    else:
        pass