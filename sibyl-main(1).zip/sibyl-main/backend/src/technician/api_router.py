
APIS = ['binance', 'binance_testnet', 'kraken', 'coinbase', 'openai', 'gemini', 'hugging_face', 'coinmarketcap']