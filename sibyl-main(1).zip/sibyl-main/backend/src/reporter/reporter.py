
class Reporter:
    def __init__(self):
        pass